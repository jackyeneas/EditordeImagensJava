package imageeditor;

public class ImageEditor {

    public static void main(String[] args) {
        TelaImageEditor te = new TelaImageEditor();
        te.setVisible(true);
        
        
    }
    
}
